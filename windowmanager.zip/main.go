package main

import "log"

func main() {
	windowInfo := &NiriWindows{}
	if _, err := windowInfo.GetWindows(); err != nil {
		log.Fatalf("failed to get windows: %v", err)
	}

	niri, err := dialNiri()
	if err != nil {
		log.Fatalf("failed to connect to niri: %v", err)
	}
	defer niri.Close()

	state := NewState()
	go runEventStreamForever(state)

	if err := startServer(":6969", niri, state); err != nil {
		log.Fatalf("server error: %v", err)
	}
}
